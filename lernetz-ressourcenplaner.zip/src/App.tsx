/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { format, addMonths, subMonths, isSameDay, getDay } from 'date-fns';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus, 
  Trash2, 
  Clock, 
  Briefcase, 
  Calendar as CalendarIcon, 
  Settings,
  Users,
  Menu,
  X,
  PlusCircle,
  LogIn,
  LogOut,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Routine, Project, Allocation, MonthData, UserProfile, AppData } from './types.ts';
import { isWorkingDay, getDaysInMonth } from './utils.ts';
import { auth, db, login, logout } from './lib/firebase.ts';
import { useAuthState } from 'react-firebase-hooks/auth';
import { doc, getDoc, setDoc, onSnapshot, collection } from 'firebase/firestore';

const COLORS = [
  '#2563eb', '#7c3aed', '#db2777', '#dc2626', '#ea580c', '#d97706', '#16a34a', '#0891b2'
];

const DEFAULT_PROFILE: UserProfile = {
  id: 'default',
  name: 'Standard',
  workingDays: [1, 2, 3, 5], // Mo, Di, Mi, Fr
  hoursPerDay: 8
};

export default function App() {
  const [user, loadingAuth] = useAuthState(auth);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'plan' | 'settings'>('plan');
  const [isLoading, setIsLoading] = useState(true);
  
  const [appData, setAppData] = useState<AppData>({
    profiles: [DEFAULT_PROFILE],
    activeProfileId: 'default',
    months: {}
  });

  // Load User Settings
  useEffect(() => {
    if (loadingAuth) return;
    if (!user) {
      setIsLoading(false);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    const unsub = onSnapshot(userRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data() as { profiles: UserProfile[], activeProfileId: string };
        setAppData(prev => ({
          ...prev,
          profiles: data.profiles,
          activeProfileId: data.activeProfileId
        }));
      } else {
        // Initialize user record
        setDoc(userRef, {
          profiles: [DEFAULT_PROFILE],
          activeProfileId: 'default'
        });
      }
      setIsLoading(false);
    });

    return () => unsub();
  }, [user, loadingAuth]);

  const monthStr = format(currentDate, 'yyyy-MM');
  const activeProfile = appData.profiles.find(p => p.id === appData.activeProfileId) || DEFAULT_PROFILE;
  const monthKey = `${activeProfile.id}-${monthStr}`;

  // Load Month Data
  useEffect(() => {
    if (!user || loadingAuth) return;

    const monthRef = doc(db, 'users', user.uid, 'months', monthKey);
    const unsub = onSnapshot(monthRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data() as MonthData;
        setAppData(prev => ({
          ...prev,
          months: {
            ...prev.months,
            [monthKey]: data
          }
        }));
      }
    });

    return () => unsub();
  }, [user, loadingAuth, monthKey]);

  const monthData = useMemo((): MonthData => {
    return appData.months[monthKey] || {
      id: monthStr,
      profileId: activeProfile.id,
      projects: [],
      routines: [],
      allocations: []
    };
  }, [appData.months, monthKey, monthStr, activeProfile.id]);

  const updateMonthData = async (data: Partial<MonthData>) => {
    const newData = { ...monthData, ...data };
    setAppData(prev => ({
      ...prev,
      months: { ...prev.months, [monthKey]: newData }
    }));

    if (user) {
      const monthRef = doc(db, 'users', user.uid, 'months', monthKey);
      await setDoc(monthRef, newData);
    }
  };

  const updateProfile = async (profile: UserProfile) => {
    const newProfiles = appData.profiles.map(p => p.id === profile.id ? profile : p);
    setAppData(prev => ({ ...prev, profiles: newProfiles }));

    if (user) {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { profiles: newProfiles, activeProfileId: appData.activeProfileId });
    }
  };

  const addProfile = async (name: string) => {
    const newProfile: UserProfile = {
      id: crypto.randomUUID(),
      name,
      workingDays: [1, 2, 3, 5],
      hoursPerDay: 8
    };
    const newProfiles = [...appData.profiles, newProfile];
    setAppData(prev => ({
      ...prev,
      profiles: newProfiles,
      activeProfileId: newProfile.id
    }));

    if (user) {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { profiles: newProfiles, activeProfileId: newProfile.id });
    }
  };

  const setActiveProfile = async (id: string) => {
    setAppData(prev => ({ ...prev, activeProfileId: id }));
    if (user) {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { ...appData, activeProfileId: id }, { merge: true });
    }
  };

  const deleteProfile = async (id: string) => {
    if (appData.profiles.length <= 1) return;
    const remaining = appData.profiles.filter(p => p.id !== id);
    const newActiveId = appData.activeProfileId === id ? remaining[0].id : appData.activeProfileId;
    
    setAppData(prev => ({
      ...prev,
      profiles: remaining,
      activeProfileId: newActiveId
    }));

    if (user) {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { profiles: remaining, activeProfileId: newActiveId });
    }
  };

  // Stats calculation
  const days = useMemo(() => getDaysInMonth(monthStr), [monthStr]);
  const workingDaysCount = days.filter(d => isWorkingDay(d, activeProfile.workingDays)).length;
  const totalCapacity = workingDaysCount * activeProfile.hoursPerDay;

  const routineHoursTotal = useMemo(() => {
    let totals = 0;
    days.forEach(day => {
      if (isWorkingDay(day, activeProfile.workingDays)) {
        const dayRoutines = monthData.routines.filter(r => r.dayOfWeek === getDay(day));
        totals += dayRoutines.reduce((sum, r) => sum + r.hours, 0);
      }
    });
    return totals;
  }, [days, monthData.routines, activeProfile.workingDays]);

  const projectHoursTotal = useMemo(() => {
    return monthData.allocations.reduce((sum, a) => sum + a.hours, 0);
  }, [monthData.allocations]);

  const remainingHours = totalCapacity - routineHoursTotal - projectHoursTotal;
  const plannedPercent = totalCapacity > 0 ? Math.min(100, Math.round(((routineHoursTotal + projectHoursTotal) / totalCapacity) * 100)) : 0;

  // Handlers
  const addProject = (name: string) => {
    if (!name.trim()) return;
    const newProject: Project = {
      id: crypto.randomUUID(),
      name,
      color: COLORS[monthData.projects.length % COLORS.length]
    };
    updateMonthData({ projects: [...monthData.projects, newProject] });
  };

  const removeProject = (id: string) => {
    updateMonthData({
      projects: monthData.projects.filter(p => p.id !== id),
      allocations: monthData.allocations.filter(a => a.projectId !== id)
    });
  };

  const addRoutine = (name: string, hours: number, dayOfWeek: number) => {
    const newRoutine: Routine = { id: crypto.randomUUID(), name, hours, dayOfWeek };
    updateMonthData({ routines: [...monthData.routines, newRoutine] });
  };

  const removeRoutine = (id: string) => {
    updateMonthData({ routines: monthData.routines.filter(r => r.id !== id) });
  };

  const updateAllocation = (date: string, projectId: string, hours: number) => {
    const existingIndex = monthData.allocations.findIndex(a => a.date === date && a.projectId === projectId);
    let newAllocations = [...monthData.allocations];
    if (hours <= 0) {
      newAllocations = newAllocations.filter((_, i) => i !== existingIndex);
    } else if (existingIndex >= 0) {
      newAllocations[existingIndex] = { ...newAllocations[existingIndex], hours };
    } else {
      newAllocations.push({ id: crypto.randomUUID(), date, projectId, hours });
    }
    updateMonthData({ allocations: newAllocations });
  };

  const handlePrint = () => {
    const isIframe = window.self !== window.top;
    if (isIframe) {
      alert("Hinweis: In der Vorschau kann der PDF-Druck blockiert sein. Bitte öffne die App über den Share-Link in einem neuen Tab (und dort ggf. erneut anmelden) für den besten PDF-Export!");
    }
    window.print();
  };

  if (loadingAuth || (user && isLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-sm font-medium text-slate-500">Lade Daten...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-[10px] font-bold uppercase tracking-[0.3em] text-indigo-600 mb-8">Ausbildung @ Lernetz</h1>
        <div className="max-w-md space-y-6">
          <h2 className="text-5xl font-light tracking-tighter text-slate-900">Ressourcenplan</h2>
          <p className="text-slate-500 text-lg leading-relaxed">
            Verwalte deine Projekte und täglichen Aufgaben effizient. Sicher gespeichert & jederzeit verfügbar.
          </p>
          <button 
            onClick={() => login()}
            className="w-full flex items-center justify-center gap-3 bg-[#1a1a1a] text-white py-5 rounded-2xl text-sm font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl shadow-indigo-100"
          >
            <LogIn className="w-5 h-5" /> Mit Google Anmelden
          </button>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider !mt-12">
            BEACHTE: Deine E-Mail wird nur zur Authentifizierung genutzt und nicht in der Datenbank gespeichert.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#fdfdfd] text-[#1a1a1a] font-sans pb-40 lg:pb-32">
      <div className="max-w-[1440px] mx-auto">
        
        {/* Responsive Header */}
        <header className="flex flex-col md:flex-row items-start md:items-end justify-between px-6 md:px-10 py-6 md:py-12 border-b border-black/5">
          <div className="w-full md:w-auto flex justify-between items-start">
            <div>
              <h1 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400 mb-1">Ausbildung @ Lernetz</h1>
              <h2 className="text-2xl md:text-4xl font-light tracking-tight flex items-center gap-2 md:gap-4 flex-wrap">
                <button onClick={() => setCurrentDate(subMonths(currentDate, 1))} className="p-1 hover:bg-slate-100 rounded text-slate-300 transition-colors">
                  <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
                </button>
                <span>
                  Ressourcenplan <span className="font-medium">{format(currentDate, 'MMMM yyyy')}</span>
                </span>
                <button onClick={() => setCurrentDate(addMonths(currentDate, 1))} className="p-1 hover:bg-slate-100 rounded text-slate-300 transition-colors">
                  <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setSidebarOpen(!isSidebarOpen)}
                className="md:hidden p-2 text-slate-500 hover:bg-slate-100 rounded"
              >
                <Menu className="w-6 h-6" />
              </button>
              <button 
                onClick={() => logout()}
                className="md:hidden p-2 text-rose-500 hover:bg-rose-50 rounded"
                title="Abmelden"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className="hidden lg:flex gap-8 text-right items-end">
            <div className="flex items-center gap-4 border-r border-black/5 pr-8">
              <span className="text-[10px] uppercase font-bold text-slate-400">Profil</span>
              <select 
                value={appData.activeProfileId}
                onChange={e => setActiveProfile(e.target.value)}
                className="bg-transparent font-bold text-sm uppercase focus:outline-none cursor-pointer"
              >
                {appData.profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <div className="flex gap-1">
                <button 
                  onClick={() => setActiveTab(activeTab === 'settings' ? 'plan' : 'settings')}
                  className={`p-2 rounded-full transition-colors ${activeTab === 'settings' ? 'bg-indigo-600 text-white' : 'hover:bg-slate-100 text-slate-400'}`}
                >
                  <Settings className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => logout()}
                  className="p-2 rounded-full text-rose-400 hover:bg-rose-50 transition-colors"
                  title="Abmelden"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Arbeitstage</p>
              <p className="text-xl font-light">{workingDaysCount} Tage / Monat</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Kapazität</p>
              <p className="text-xl font-light italic">{totalCapacity}h</p>
            </div>
          </div>
        </header>

        {activeTab === 'settings' ? (
          <SettingsPanel 
            appData={appData} 
            updateProfile={updateProfile}
            addProfile={addProfile}
            deleteProfile={deleteProfile}
            close={() => setActiveTab('plan')} 
          />
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[600px]">
            
            {/* Sidebar Desktop */}
            <aside className="hidden lg:block lg:col-span-3 border-r border-black/5 p-8 space-y-10 bg-[#f9f9f9]/50">
              <ProjectSection projects={monthData.projects} onAdd={addProject} onRemove={removeProject} />
              <RoutineSection routines={monthData.routines} onAdd={addRoutine} onRemove={removeRoutine} />
            </aside>

            {/* Mobile Sidebar Overlay */}
            <AnimatePresence>
              {isSidebarOpen && (
                <>
                  <motion.div 
                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                    onClick={() => setSidebarOpen(false)}
                    className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60] lg:hidden"
                  />
                  <motion.aside 
                    initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
                    className="fixed right-0 top-0 bottom-0 w-80 bg-white z-[70] p-6 shadow-2xl lg:hidden overflow-y-auto"
                  >
                    <div className="flex justify-between items-center mb-8">
                      <h3 className="font-bold flex items-center gap-2 uppercase tracking-widest text-[10px] text-slate-400">Menü</h3>
                      <button onClick={() => setSidebarOpen(false)}><X className="w-5 h-5" /></button>
                    </div>
                    
                    <div className="space-y-10">
                      <section className="mb-6">
                        <div className="text-[10px] font-bold uppercase mb-4 text-indigo-600 border-b-2 border-indigo-600 pb-1 w-fit">Aktives Profil</div>
                        <select 
                          value={appData.activeProfileId}
                          onChange={e => { setActiveProfile(e.target.value); setSidebarOpen(false); }}
                          className="w-full p-3 bg-slate-50 rounded-lg font-bold text-sm focus:outline-none"
                        >
                          {appData.profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                        </select>
                        <button 
                          onClick={() => { setActiveTab('settings'); setSidebarOpen(false); }}
                          className="mt-4 w-full flex items-center justify-center gap-2 p-3 border border-slate-100 rounded-lg text-sm font-medium hover:bg-slate-50"
                        >
                          <Settings className="w-4 h-4" /> Profile verwalten
                        </button>
                      </section>
                      <ProjectSection projects={monthData.projects} onAdd={addProject} onRemove={removeProject} />
                      <RoutineSection routines={monthData.routines} onAdd={addRoutine} onRemove={removeRoutine} />
                    </div>
                  </motion.aside>
                </>
              )}
            </AnimatePresence>

            {/* Main Table Area */}
            <main className="lg:col-span-9 bg-slate-50/30">
              <div className="overflow-x-auto w-full">
                <table className="w-full border-collapse bg-white min-w-[700px]">
                  <thead>
                    <tr className="border-b border-black/5 bg-[#fdfdfd] sticky top-0 z-10 shadow-sm">
                      <th className="p-4 md:p-6 text-[10px] font-bold uppercase tracking-widest text-slate-400 w-24">Datum</th>
                      <th className="p-4 md:p-6 text-[10px] font-bold uppercase tracking-widest text-slate-400">Routinen</th>
                      {monthData.projects.map(p => (
                        <th key={p.id} className="p-4 md:p-6 text-[10px] font-bold uppercase tracking-widest border-l border-black/5 min-w-[100px]" style={{ color: p.color }}>
                          {p.name}
                        </th>
                      ))}
                      <th className="p-4 md:p-6 text-[10px] font-bold uppercase tracking-widest text-slate-400 text-right border-l border-black/5 w-20">Offen</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black/5">
                    {days.map((day, index) => {
                      const dateStr = format(day, 'yyyy-MM-dd');
                      const isWork = isWorkingDay(day, activeProfile.workingDays);
                      const dayOfWeek = getDay(day);
                      const isLastDayOfWeek = dayOfWeek === 0 || index === days.length - 1;
                      const dayRoutines = monthData.routines.filter(r => r.dayOfWeek === dayOfWeek);
                      const routineHours = isWork ? dayRoutines.reduce((sum, r) => sum + r.hours, 0) : 0;
                      const dayAllocations = monthData.allocations.filter(a => a.date === dateStr);
                      const allocatedHours = dayAllocations.reduce((sum, a) => sum + a.hours, 0);
                      const remaining = (isWork ? activeProfile.hoursPerDay : 0) - routineHours - allocatedHours;

                      let kw = null;
                      if (isLastDayOfWeek) kw = format(day, 'w');

                      return (
                        <React.Fragment key={dateStr}>
                          <tr className={`group transition-colors ${!isWork ? 'bg-slate-50/50' : 'hover:bg-indigo-50/10'}`}>
                            <td className="p-3 md:p-4 px-6 whitespace-nowrap">
                              <div className={`text-lg md:text-xl font-light tracking-tight ${!isWork ? 'text-slate-300' : 'text-slate-700 font-medium'}`}>{format(day, 'dd')}.</div>
                              <div className="text-[10px] font-bold uppercase text-slate-400">{format(day, 'EEE')}</div>
                            </td>
                            <td className="p-3 md:p-4 px-6">
                              {isWork ? (
                                <div className="flex flex-wrap gap-1">
                                  {dayRoutines.map(r => (
                                    <div key={r.id} className="bg-amber-50 text-amber-700 text-[10px] font-bold uppercase px-2 py-0.5 rounded border border-amber-100 flex items-center gap-1 group/item">
                                      {r.name} <span className="opacity-50 font-medium">{r.hours}h</span>
                                    </div>
                                  ))}
                                  {dayRoutines.length === 0 && <span className="text-[10px] uppercase font-medium text-slate-300">Frei</span>}
                                </div>
                              ) : (
                                <span className="text-[10px] font-bold text-slate-200">OFF</span>
                              )}
                            </td>
                            {monthData.projects.map(p => (
                              <td key={p.id} className="p-1 border-l border-black/5">
                                {isWork && (
                                  <div className="relative group/input">
                                    <input 
                                      type="number" min="0" step="0.5"
                                      className="w-full text-center py-3 bg-transparent focus:outline-none focus:bg-indigo-50/30 text-sm font-medium transition-all"
                                      value={dayAllocations.find(a => a.projectId === p.id)?.hours || ''}
                                      onChange={(e) => updateAllocation(dateStr, p.id, parseFloat(e.target.value) || 0)}
                                      placeholder="-"
                                    />
                                    {dayAllocations.find(a => a.projectId === p.id) && (
                                      <div className="absolute bottom-0 left-0 h-0.5 w-full" style={{ backgroundColor: p.color, opacity: 0.3 }} />
                                    )}
                                  </div>
                                )}
                              </td>
                            ))}
                            <td className={`p-3 md:p-4 px-6 text-right font-mono text-sm border-l border-black/5 ${remaining < 0 ? 'text-rose-500 font-bold' : remaining === 0 ? 'text-slate-200' : 'text-indigo-500 font-medium'}`}>
                              {isWork ? `${remaining}h` : ''}
                            </td>
                          </tr>
                          {kw && (
                            <tr className="bg-slate-900/95 text-white/40">
                              <td colSpan={2 + monthData.projects.length} className="p-2 md:p-3 px-6 text-[9px] md:text-[10px] uppercase font-bold tracking-[0.2em]">
                                KW {kw} Wochenende
                              </td>
                              <td className="p-2 md:p-3 px-6 text-right text-[10px] font-bold text-white uppercase border-l border-white/5">KW {kw}</td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </main>
          </div>
        )}
      </div>

      {/* Persistent Summary Bar */}
      <footer className="fixed bottom-0 left-0 right-0 bg-[#0a0a0a] text-white p-4 md:p-8 z-50 shadow-[0_-10px_30px_rgba(0,0,0,0.3)]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 md:gap-12">
          <div className="flex gap-10 md:gap-16 w-full md:w-auto justify-center md:justify-start">
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-1 font-bold">Verplant</span>
              <span className="text-2xl md:text-3xl font-light">{(routineHoursTotal + projectHoursTotal).toFixed(1)}h</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-[0.2em] text-slate-500 mb-1 font-bold">Verfügbar</span>
              <span className={`text-2xl md:text-3xl font-light ${remainingHours < 0 ? 'text-rose-500 underline' : 'text-indigo-400'}`}>
                {remainingHours.toFixed(1)}h
              </span>
            </div>
          </div>

          <div className="flex-1 max-sm w-full hidden md:block">
            <div className="flex justify-between text-[10px] uppercase tracking-widest mb-2 font-bold text-slate-400">
              <span>Fortschritt</span>
              <span className="text-white">{plannedPercent}%</span>
            </div>
            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="bg-indigo-500 h-full transition-all duration-700 ease-out" 
                style={{ width: `${plannedPercent}%` }} 
              />
            </div>
          </div>

          <div className="flex gap-2 md:gap-4 w-full md:w-auto">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="md:hidden flex-1 p-3 bg-white/10 text-white rounded-sm text-[10px] font-bold uppercase tracking-widest"
            >
              Menü
            </button>
            <button 
              onClick={handlePrint}
              className="flex-1 md:flex-none h-12 px-6 bg-white text-black hover:bg-slate-200 flex items-center justify-center rounded-sm text-[10px] font-bold uppercase transition-colors"
            >
              PDF Export
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ProjectSection({ projects, onAdd, onRemove }) {
  return (
    <section>
      <div className="text-[10px] font-bold uppercase mb-6 text-indigo-600 border-b-2 border-indigo-600 pb-1 w-fit flex items-center gap-2">
        <Briefcase className="w-3 h-3" /> Projekte
      </div>
      <div className="space-y-2 mb-4">
        {projects.map(p => (
          <div key={p.id} className="group flex items-center justify-between bg-white px-4 py-3 border border-slate-100 rounded shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
              <span className="text-sm font-medium tracking-tight truncate max-w-[150px]">{p.name}</span>
            </div>
            <button onClick={() => onRemove(p.id)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-500 transition-all">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      <AddInput placeholder="Projekt Name..." onAdd={onAdd} />
    </section>
  );
}

function RoutineSection({ routines, onAdd, onRemove }) {
  const [isAdding, setIsAdding] = useState(false);
  return (
    <section>
      <div className="flex justify-between items-center mb-6 border-b-2 border-amber-500 pb-1 w-fit">
        <div className="text-[10px] font-bold uppercase text-amber-600 flex items-center gap-2">
          <Clock className="w-3 h-3" /> Tägliche Routinen
        </div>
      </div>
      <div className="space-y-2 mb-4">
        {routines.map(r => (
          <div key={r.id} className="group flex items-center justify-between bg-white px-4 py-3 border border-slate-100 rounded shadow-sm">
            <div className="flex flex-col">
              <span className="text-sm font-bold tracking-tight">{r.name}</span>
              <span className="text-[9px] text-slate-400 uppercase font-bold">
                {['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][r.dayOfWeek]} • {r.hours}h
              </span>
            </div>
            <button onClick={() => onRemove(r.id)} className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-rose-500 transition-all">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      {isAdding ? (
        <AddRoutinePanel onAdd={(n, h, d) => { onAdd(n, h, d); setIsAdding(false); }} onCancel={() => setIsAdding(false)} />
      ) : (
        <button 
          onClick={() => setIsAdding(true)}
          className="w-full py-2 border border-dashed border-slate-200 text-slate-400 rounded-lg text-xs font-medium hover:border-indigo-300 hover:text-indigo-400 transition-all flex items-center justify-center gap-1"
        >
          <Plus className="w-3 h-3" /> Routine hinzufügen
        </button>
      )}
    </section>
  );
}

function SettingsPanel({ appData, updateProfile, addProfile, deleteProfile, close }) {
  const [newProfileName, setNewProfileName] = useState('');
  
  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-12">
        <h2 className="text-3xl font-light tracking-tight">Profil <span className="font-medium">Einstellungen</span></h2>
        <button onClick={close} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-6 h-6" /></button>
      </div>

      <div className="space-y-12">
        {appData.profiles.map(profile => (
          <section key={profile.id} className="bg-white p-8 border border-black/5 rounded-xl shadow-sm space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <Users className="w-6 h-6 text-indigo-600" />
                <h3 className="text-xl font-bold">{profile.name}</h3>
              </div>
              {appData.profiles.length > 1 && (
                <button onClick={() => deleteProfile(profile.id)} className="text-rose-500 p-2 hover:bg-rose-50 rounded-lg transition-colors">
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-4">Arbeitstage</label>
                <div className="flex flex-wrap gap-2">
                  {[1, 2, 3, 4, 5, 6, 0].map(d => {
                    const isActive = profile.workingDays.includes(d);
                    const label = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d];
                    return (
                      <button 
                        key={d}
                        onClick={() => {
                          const newDays = isActive ? profile.workingDays.filter(day => day !== d) : [...profile.workingDays, d];
                          updateProfile({ ...profile, workingDays: newDays });
                        }}
                        className={`w-10 h-10 rounded-sm text-xs font-bold transition-all ${isActive ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-50 text-slate-400 border border-slate-100'}`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>
              
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-4">Stunden pro Tag</label>
                <div className="flex items-center gap-4">
                  <input 
                    type="range" min="1" max="12" step="0.5"
                    value={profile.hoursPerDay}
                    onChange={e => updateProfile({ ...profile, hoursPerDay: parseFloat(e.target.value) })}
                    className="flex-1 accent-indigo-600"
                  />
                  <span className="text-xl font-mono font-bold w-12">{profile.hoursPerDay}h</span>
                </div>
              </div>
            </div>
          </section>
        ))}

        <section className="bg-slate-50 p-8 rounded-xl border border-dotted border-slate-300">
          <h3 className="text-lg font-bold mb-4">Weiteres Profil hinzufügen</h3>
          <div className="flex gap-4">
            <input 
              value={newProfileName}
              onChange={e => setNewProfileName(e.target.value)}
              placeholder="Name des Benutzers..."
              className="flex-1 bg-white border border-slate-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-1 focus:ring-indigo-100 shadow-sm"
            />
            <button 
              onClick={() => { if (newProfileName) { addProfile(newProfileName); setNewProfileName(''); } }}
              className="bg-[#1a1a1a] text-white px-6 py-3 rounded-lg text-sm font-bold uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-2"
            >
              <PlusCircle className="w-5 h-5" /> Erstellen
            </button>
          </div>
        </section>
      </div>

      <div className="mt-12 text-center">
        <button onClick={close} className="text-indigo-600 font-bold uppercase text-[10px] tracking-widest hover:underline px-6 py-4">Zurück zur Planung</button>
      </div>
    </div>
  );
}

function AddInput({ placeholder, onAdd }) {
  const [val, setVal] = useState('');
  return (
    <div className="flex items-center gap-2 border-b border-black/10 py-1">
      <input 
        value={val}
        onChange={e => setVal(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') { onAdd(val); setVal(''); } }}
        placeholder={placeholder}
        className="bg-transparent border-none text-sm focus:outline-none flex-1 py-1 placeholder:text-slate-300 font-medium tracking-tight"
      />
      <button onClick={() => { onAdd(val); setVal(''); }} className="text-slate-400 hover:text-indigo-600 p-1">
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}

function AddRoutinePanel({ onAdd, onCancel }) {
  const [name, setName] = useState('');
  const [hours, setHours] = useState('2');
  const [day, setDay] = useState('3'); 

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 p-4 bg-slate-50 border border-slate-100 rounded-lg">
      <input 
        value={name} onChange={e => setName(e.target.value)}
        placeholder="Z.B. Ämtli..."
        className="w-full bg-white border border-slate-100 rounded px-4 py-2 text-sm focus:outline-none shadow-sm font-medium"
      />
      <div className="flex gap-2">
        <select 
          value={day} onChange={e => setDay(e.target.value)}
          className="flex-1 bg-white border border-slate-100 rounded px-2 py-2 text-xs font-bold uppercase text-slate-500"
        >
          <option value="1">Mo</option><option value="2">Di</option><option value="3">Mi</option>
          <option value="4">Do</option><option value="5">Fr</option>
        </select>
        <input 
          type="number" value={hours} onChange={e => setHours(e.target.value)}
          className="w-14 bg-white border border-slate-100 rounded px-2 py-2 text-sm text-center font-mono"
        />
        <button 
          onClick={() => { if (name) onAdd(name, parseFloat(hours), parseInt(day)); }}
          className="p-2 bg-slate-900 text-white rounded md:px-4"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
      <button onClick={onCancel} className="text-[10px] w-full text-slate-400 font-bold uppercase hover:text-slate-600">Abbrechen</button>
    </motion.div>
  );
}

