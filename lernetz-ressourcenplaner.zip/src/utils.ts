/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay } from 'date-fns';

export function isWorkingDay(date: Date, workingDays: number[]): boolean {
  return workingDays.includes(getDay(date));
}

export function getDaysInMonth(monthId: string): Date[] {
  const [year, month] = monthId.split('-').map(Number);
  const start = startOfMonth(new Date(year, month - 1));
  const end = endOfMonth(start);
  return eachDayOfInterval({ start, end });
}

export function getMonthName(monthId: string): string {
  const [year, month] = monthId.split('-').map(Number);
  return format(new Date(year, month - 1), 'MMMM yyyy', { 
    // locale could be added here for German names
  });
}
