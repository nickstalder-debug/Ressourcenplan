/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Routine {
  id: string;
  name: string;
  hours: number;
  dayOfWeek: number; // 0-6 (Sun-Sat)
}

export interface Project {
  id: string;
  name: string;
  color: string;
}

export interface Allocation {
  id: string;
  date: string; // ISO format YYYY-MM-DD
  projectId: string;
  hours: number;
}

export interface UserProfile {
  id: string;
  name: string;
  workingDays: number[]; // e.g. [1, 2, 3, 5]
  hoursPerDay: number;
}

export interface MonthData {
  id: string; // YYYY-MM
  profileId: string;
  projects: Project[];
  routines: Routine[];
  allocations: Allocation[];
}

export interface AppData {
  profiles: UserProfile[];
  activeProfileId: string;
  months: Record<string, MonthData>; // Key: "profileId-YYYY-MM"
}
